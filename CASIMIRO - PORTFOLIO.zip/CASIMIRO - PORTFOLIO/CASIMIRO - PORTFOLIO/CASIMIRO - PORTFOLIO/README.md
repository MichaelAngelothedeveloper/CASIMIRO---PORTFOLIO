# lastname-portfolio
Foundation: HTML + CSS + JavaScript + React (CDN, no build).
Open index.html (or Live Server). Needs internet.

- index.html        -> HTML
- css/style.css     -> CSS
- js/script.js      -> JavaScript (data)
- react/*.js        -> React (components, pages, routing)
