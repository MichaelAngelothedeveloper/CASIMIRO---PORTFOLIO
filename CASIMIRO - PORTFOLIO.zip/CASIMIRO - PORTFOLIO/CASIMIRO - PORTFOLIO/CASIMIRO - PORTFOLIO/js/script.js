
const PORTFOLIO = {
  name: "Michael",
  tagline: "Welcome to my portfolio!",
  about:
    "I'm a third-year BSIT student at Gordon College. I'm a student athlete of Gordon College. I love playing sepak takraw because it has taught me a lot, not only about the game but also about the real challenges of life.",
  skills: ["HTML & CSS", "JavaScript"],
  projects: [
    {
      title: "Barangay Request Forms System",
      description: "A web platform for requesting barangay documents online for Barangay San Jose, Castillejos, Zambales.",
      image: "images/barangay-san-jose.png",
    },
    {
      title: "Calculator",
      description: "A simple calculator web app with basic operations like add, subtract, multiply, divide, and percent.",
      image: "images/calculator.png",
    },
  ],
  email: "202411262@gordoncollege.edu.ph",
};

function setPageTitle(page) {
  document.title = page + " | " + PORTFOLIO.name;
}
