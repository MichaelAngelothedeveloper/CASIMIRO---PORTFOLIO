// ===== REACT: routing + render =====
const { HashRouter, Routes, Route } = ReactRouterDOM;

function App() {
  return html`
    <${Routes}>
      <${Route} path="/" element=${html`<${Layout} />`}>
        <${Route} index element=${html`<${Home} />`} />
        <${Route} path="about" element=${html`<${About} />`} />
        <${Route} path="projects" element=${html`<${Projects} />`} />
        <${Route} path="contact" element=${html`<${Contact} />`} />
      <//>
    <//>
  `;
}

ReactDOM.createRoot(document.getElementById("root")).render(
  html`<${HashRouter}><${App} /><//>`
);
