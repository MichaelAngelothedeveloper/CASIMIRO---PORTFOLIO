// ===== REACT: shared layout components =====
const { NavLink, Outlet } = ReactRouterDOM;
const html = htm.bind(React.createElement); // JSX-like syntax, no build needed

function Header() {
  return html`
    <header className="site-header">
      <h1>${PORTFOLIO.name}</h1>
      <nav className="site-nav">
        <${NavLink} to="/">Home<//>
        <${NavLink} to="/about">About<//>
        <${NavLink} to="/projects">Projects<//>
        <${NavLink} to="/contact">Contact<//>
      </nav>
    </header>
  `;
}

function Footer() {
  return html`
    <footer className="site-footer">
      <p>© ${new Date().getFullYear()} ${PORTFOLIO.name}. All rights reserved.</p>
    </footer>
  `;
}

function Layout() {
  return html`
    <${Header} />
    <main className="main"><${Outlet} /></main>
    <${Footer} />
  `;
}
