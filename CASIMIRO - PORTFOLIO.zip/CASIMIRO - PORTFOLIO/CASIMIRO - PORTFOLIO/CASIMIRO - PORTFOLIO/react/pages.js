// ===== REACT: pages =====
function Home() {
  setPageTitle("Home");
  return html`
    <section className="hero">
      <h2>Hi, I'm ${PORTFOLIO.name}</h2>
      <p>${PORTFOLIO.tagline}</p>
    </section>
  `;
}

function About() {
  setPageTitle("About");
  return html`
    <section className="page-card">
      <h2>About Me</h2>
      <p>${PORTFOLIO.about}</p>
      <h3>Skills</h3>
      <ul className="skills">
        ${PORTFOLIO.skills.map((s) => html`<li key=${s}>${s}</li>`)}
      </ul>
    </section>
  `;
}

function Projects() {
  setPageTitle("Projects");
  return html`
    <section>
      <h2>Projects</h2>
      <div className="project-grid">
        ${PORTFOLIO.projects.map(
          (p) => html`
            <article className="project-card" key=${p.title}>
              <img src=${p.image} alt=${p.title} />
              <div className="info">
                <h3>${p.title}</h3>
                <p>${p.description}</p>
              </div>
            </article>
          `
        )}
      </div>
    </section>
  `;
}

function Contact() {
  setPageTitle("Contact");
  return html`
    <section className="page-card">
      <h2>Contact</h2>
      <p>Email: ${PORTFOLIO.email}</p>
    </section>
  `;
}
