const PORTFOLIO = {
  name: "Michael Casimiro",
  role: "Frontend Developer in training",
  intro:
    "I'm a third-year BSIT student at Gordon College. I build web pages and small apps with HTML, CSS, JavaScript and React, and I'm working toward becoming a frontend developer.",

  snapshot: [
    { key: "role", value: "Frontend Developer" },
    { key: "school", value: "Gordon College" },
    { key: "program", value: "BSIT, third year" },
    { key: "stack", value: ["HTML & CSS", "JavaScript", "React", "Tailwind CSS"] },
    { key: "sport", value: "Sepak takraw" },
  ],

  about: [
    "I'm a third-year Bachelor of Science in Information Technology student at Gordon College. I like turning an idea into a page that people can actually use, and I'm learning how to make that page clear, responsive and easy to navigate.",
  ],
  beyondCode:
    "I'm a student athlete of Gordon College. I love playing sepak takraw because it has taught me a lot, not only about the game but also about the real challenges of life. I bring the same habits to my code: practice often, learn from mistakes and keep improving.",
  facts: [
    { label: "School", value: "Gordon College" },
    { label: "Program", value: "BS Information Technology" },
    { label: "Year level", value: "Third year" },
    { label: "Focus", value: "Frontend development" },
    { label: "Sport", value: "Sepak takraw" },
  ],

  skillGroups: [
    { title: "Languages", items: ["HTML", "CSS", "JavaScript"] },
    { title: "Frameworks and tools", items: ["React", "React Router", "Tailwind CSS"] },
    { title: "Practices", items: ["Responsive design", "Web accessibility basics"] },
  ],

  projects: [
    {
      title: "Barangay Request Forms System",
      description:
        "A web platform for requesting barangay documents online, made for Barangay San Jose in Castillejos, Zambales. It has separate portals for barangay officials and for residents who want to request documents.",
      image: "images/barangay-san-jose.png",
      imageAlt:
        "Home page of the Barangay San Jose website with the barangay seal, a short welcome message, and Admin Portal and Resident Portal buttons.",
      fit: "cover", 
      links: [],
    },
    {
      title: "Calculator",
      description:
        "A simple calculator web app that handles addition, subtraction, multiplication, division and percent, with buttons to clear everything or delete the last digit.",
      image: "images/calculator.png",
      imageAlt:
        "A dark calculator with a number display, orange operator buttons, red clear and delete buttons, and a green equals button.",
      fit: "contain",
      links: [],
    },
  ],

  contact: {
    email: "202411262@gordoncollege.edu.ph",
  },
};

const CONTACT_LINKS = [
  PORTFOLIO.contact.email && {
    label: "Email",
    text: PORTFOLIO.contact.email,
    href: "mailto:" + PORTFOLIO.contact.email,
  },
  PORTFOLIO.contact.github && {
    label: "GitHub",
    text: PORTFOLIO.contact.github.replace("https://", ""),
    href: PORTFOLIO.contact.github,
  },
  PORTFOLIO.contact.linkedin && {
    label: "LinkedIn",
    text: PORTFOLIO.contact.linkedin.replace("https://", ""),
    href: PORTFOLIO.contact.linkedin,
  },
].filter(Boolean);


const GMAIL_COMPOSE_URL =
  "https://mail.google.com/mail/?view=cm&fs=1" +
  "&to=" + encodeURIComponent(PORTFOLIO.contact.email) +
  "&su=" + encodeURIComponent("Hello Michael, I saw your portfolio");

function setPageTitle(page) {
  document.title = page
    ? page + " | " + PORTFOLIO.name
    : PORTFOLIO.name + " | Frontend Developer Portfolio";
}
