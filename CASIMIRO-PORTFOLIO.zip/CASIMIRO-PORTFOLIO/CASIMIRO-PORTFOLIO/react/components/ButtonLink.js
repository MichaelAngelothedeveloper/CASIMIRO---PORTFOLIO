function buttonClasses(variant = "primary") {
  const base =
    "inline-flex items-center justify-center rounded-lg px-6 py-3 font-semibold transition-colors";
  const styles = {
    primary: "bg-ink text-white hover:bg-brand", // navy button on light backgrounds
    secondary: "border border-ink text-ink hover:bg-tint", // outline button on light backgrounds
    light: "bg-white text-ink hover:bg-sky-soft", // for dark (navy) sections
  };
  return base + " " + styles[variant];
}

function ButtonLink({ to, variant, children }) {
  return html`<${Link} to=${to} className=${buttonClasses(variant)}>${children}<//>`;
}
