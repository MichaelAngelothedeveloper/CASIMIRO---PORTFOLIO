function CodeCard() {
  const keyword = (text) => html`<span className="text-sky">${text}</span>`;
  const property = (text) => html`<span className="text-mist">${text}</span>`;
  const string = (text) => html`<span className="text-[#a8e0c0]">"${text}"</span>`;

  const rows = [[0, [keyword("const"), " developer = {"]]];
  PORTFOLIO.snapshot.forEach(({ key, value }) => {
    if (Array.isArray(value)) {
      rows.push([1, [property(key), ": ["]]);
      value.forEach((item) => rows.push([2, [string(item), ","]]));
      rows.push([1, ["],"]]);
    } else {
      rows.push([1, [property(key), ": ", string(value), ","]]);
    }
  });
  rows.push([0, ["};"]]);

  return html`
    <div className="relative min-w-0">
      <div className="absolute inset-0 translate-x-3 translate-y-3 rounded-xl bg-sky-soft" aria-hidden="true"></div>
      <div className="relative overflow-hidden rounded-xl bg-ink shadow-xl shadow-ink/20">
        <div className="flex items-center gap-2 border-b border-white/15 px-4 py-3" aria-hidden="true">
          <span className="h-3 w-3 rounded-full bg-white/25"></span>
          <span className="h-3 w-3 rounded-full bg-white/25"></span>
          <span className="h-3 w-3 rounded-full bg-white/25"></span>
          <span className="ml-3 font-mono text-xs text-mist-muted">developer.js</span>
        </div>
        <pre className="overflow-x-auto p-5 font-mono text-xs leading-7 text-mist-muted sm:text-sm"><code>${rows.map(
          ([indent, parts], i) => html`
            <span key=${i} className="block" style=${{ paddingLeft: indent * 1.5 + "rem" }}>
              ${React.Children.toArray(parts)}
            </span>
          `
        )}</code></pre>
      </div>
    </div>
  `;
}
