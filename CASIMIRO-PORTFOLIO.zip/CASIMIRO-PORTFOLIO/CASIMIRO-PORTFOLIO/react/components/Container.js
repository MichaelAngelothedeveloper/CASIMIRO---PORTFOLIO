function Container({ children, className = "" }) {
  return html`
    <div className=${"mx-auto w-full max-w-6xl px-5 sm:px-8 " + className}>${children}</div>
  `;
}
