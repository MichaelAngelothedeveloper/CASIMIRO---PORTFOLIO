function ExternalLink({ href, children, className = "" }) {
  const newTab = href.startsWith("http");
  const extra = newTab ? { target: "_blank", rel: "noopener noreferrer" } : {};
  return html`
    <a href=${href} className=${className} ...${extra}>
      ${children}${newTab && html`<span className="sr-only"> (opens in a new tab)</span>`}
    </a>
  `;
}
