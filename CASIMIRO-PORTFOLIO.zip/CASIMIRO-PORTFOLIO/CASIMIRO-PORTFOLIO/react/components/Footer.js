function Footer() {
  const linkStyle = "text-mist-muted underline-offset-4 hover:text-white hover:underline";

  return html`
    <footer className="bg-ink text-mist">
      <${Container} className="grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-3">
        <div>
          <p className="font-display text-xl font-extrabold">${PORTFOLIO.name}</p>
          <p className="mt-2 max-w-xs text-mist-muted">${PORTFOLIO.role}. BSIT student at Gordon College.</p>
        </div>

        <nav aria-label="Footer">
          <h2 className="font-display text-lg font-bold">Pages</h2>
          <ul className="mt-3 space-y-2">
            ${NAV_ITEMS.map(
              (item) => html`
                <li key=${item.to}><${Link} to=${item.to} className=${linkStyle}>${item.label}<//></li>
              `
            )}
          </ul>
        </nav>

        <div>
          <h2 className="font-display text-lg font-bold">Contact</h2>
          <ul className="mt-3 space-y-2">
            ${CONTACT_LINKS.map(
              (c) => html`
                <li key=${c.label}><${ExternalLink} href=${c.href} className=${linkStyle}>${c.label}<//></li>
              `
            )}
          </ul>
        </div>
      <//>

      <div className="border-t border-white/15 py-5 text-center text-sm text-mist-muted">
        © ${new Date().getFullYear()} ${PORTFOLIO.name}. All rights reserved.
      </div>
    </footer>
  `;
}
