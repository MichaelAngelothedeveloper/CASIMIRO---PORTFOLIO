const NAV_ITEMS = [
  { to: "/", label: "Home", end: true },
  { to: "/about", label: "About" },
  { to: "/projects", label: "Projects" },
  { to: "/contact", label: "Contact" },
];

function Header() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return html`
    <header className="sticky top-0 z-40 border-b border-line bg-page/95 backdrop-blur">
      <${Container} className="flex flex-wrap items-center justify-between py-3">
        <${Link} to="/" className="flex items-center gap-3 font-display text-lg font-extrabold">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-ink text-sm text-white" aria-hidden="true">MC</span>
          ${PORTFOLIO.name}
        <//>

        <button
          type="button"
          className="inline-flex items-center gap-2 rounded-lg border border-line bg-surface px-3 py-2 text-sm font-semibold hover:bg-tint md:hidden"
          aria-expanded=${open}
          aria-controls="primary-nav"
          onClick=${() => setOpen(!open)}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d=${open ? "M6 6l12 12M18 6L6 18" : "M4 7h16M4 12h16M4 17h16"} />
          </svg>
          Menu
        </button>

        <nav
          id="primary-nav"
          aria-label="Main"
          className=${(open ? "block" : "hidden") + " basis-full md:block md:basis-auto"}
        >
          <ul className="flex flex-col gap-1 py-3 md:flex-row md:gap-1 md:py-0">
            ${NAV_ITEMS.map(
              (item) => html`
                <li key=${item.to}>
                  <${NavLink}
                    to=${item.to}
                    end=${item.end}
                    className="block rounded-lg px-4 py-2 font-medium text-ink-soft transition-colors hover:bg-tint hover:text-ink aria-[current=page]:bg-ink aria-[current=page]:text-white"
                  >
                    ${item.label}
                  <//>
                </li>
              `
            )}
          </ul>
        </nav>
      <//>
    </header>
  `;
}
