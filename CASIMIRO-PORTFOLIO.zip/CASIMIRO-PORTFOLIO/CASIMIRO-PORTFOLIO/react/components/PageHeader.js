function PageHeader({ title, children }) {
  return html`
    <div className="border-b border-line pb-10">
      <h1 className="font-display text-4xl font-extrabold tracking-tight sm:text-5xl">${title}</h1>
      <p className="mt-4 max-w-2xl text-lg text-ink-soft">${children}</p>
    </div>
  `;
}
