function ProjectCard({ project }) {
  const { title, description, image, imageAlt, fit, links } = project;
  const imageFit = fit === "contain" ? "object-contain" : "object-cover object-top";

  return html`
    <article className="flex min-w-0 flex-col overflow-hidden rounded-xl bg-ink text-white shadow-lg shadow-ink/15">
      <div className="flex items-center gap-1.5 border-b border-white/10 bg-ink-2 px-4 py-2.5" aria-hidden="true">
        <span className="h-2.5 w-2.5 rounded-full bg-white/30"></span>
        <span className="h-2.5 w-2.5 rounded-full bg-white/30"></span>
        <span className="h-2.5 w-2.5 rounded-full bg-white/30"></span>
      </div>
      <img
        src=${image}
        alt=${imageAlt}
        loading="lazy"
        className=${"aspect-[16/10] w-full bg-ink-2 " + imageFit}
      />
      <div className="flex flex-1 flex-col gap-3 p-6">
        <h3 className="font-display text-2xl font-bold tracking-tight">${title}</h3>
        <p className="text-mist-muted">${description}</p>
        ${links.length > 0 &&
        html`
          <ul className="mt-auto flex flex-wrap gap-x-5 gap-y-2 pt-2">
            ${links.map(
              (l) => html`
                <li key=${l.label}>
                  <${ExternalLink} href=${l.href} className="font-semibold text-sky underline underline-offset-4 hover:text-white">
                    ${l.label}
                  <//>
                </li>
              `
            )}
          </ul>
        `}
      </div>
    </article>
  `;
}
