function SkillChips({ items }) {
  return html`
    <ul className="flex flex-wrap gap-2">
      ${items.map(
        (item) => html`
          <li key=${item} className="rounded-md bg-tint px-3 py-1.5 text-sm font-medium text-ink">
            ${item}
          </li>
        `
      )}
    </ul>
  `;
}
