function usePageTitle(page) {
  useEffect(() => {
    setPageTitle(page);
  }, [page]);
}
