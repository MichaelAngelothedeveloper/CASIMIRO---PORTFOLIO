function About() {
  usePageTitle("About");

  return html`
    <${Container} className="py-12 sm:py-16">
      <${PageHeader} title="About me">
        Who I am, what I'm studying and the skills I'm building.
      <//>

      <div className="mt-12 grid gap-8 lg:grid-cols-3">
        <div className="min-w-0 space-y-8 lg:col-span-2">
          <section aria-labelledby="background-heading" className="rounded-xl bg-ink p-6 text-white sm:p-8">
            <h2 id="background-heading" className="font-display text-2xl font-bold">Background</h2>
            <div className="mt-4 max-w-prose space-y-4 text-lg text-mist-muted">
              ${PORTFOLIO.about.map((text) => html`<p key=${text}>${text}</p>`)}
            </div>
          </section>

          <section aria-labelledby="beyond-heading" className="rounded-xl bg-ink p-6 text-white sm:p-8">
            <h2 id="beyond-heading" className="font-display text-2xl font-bold">Beyond the code</h2>
            <p className="mt-4 max-w-prose text-lg text-mist-muted">${PORTFOLIO.beyondCode}</p>
          </section>
        </div>

        <aside aria-labelledby="facts-heading" className="min-w-0 self-start rounded-xl bg-ink p-6 text-white sm:p-8">
          <h2 id="facts-heading" className="font-display text-xl font-bold">Quick facts</h2>
          <dl className="mt-4 divide-y divide-white/15">
            ${PORTFOLIO.facts.map(
              (f) => html`
                <div key=${f.label} className="py-3">
                  <dt className="text-sm text-mist-muted">${f.label}</dt>
                  <dd className="font-semibold">${f.value}</dd>
                </div>
              `
            )}
          </dl>
        </aside>
      </div>

      <section className="mt-16" aria-labelledby="skills-heading">
        <h2 id="skills-heading" className="font-display text-2xl font-bold">Skills</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          ${PORTFOLIO.skillGroups.map(
            (group) => html`
              <div key=${group.title} className="min-w-0 rounded-xl bg-ink p-6 text-white">
                <h3 className="mb-4 font-display text-lg font-bold">${group.title}</h3>
                <${SkillChips} items=${group.items} />
              </div>
            `
          )}
        </div>
      </section>
    <//>
  `;
}
