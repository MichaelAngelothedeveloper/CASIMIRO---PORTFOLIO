function Contact() {
  usePageTitle("Contact");

  return html`
    <${Container} className="py-12 sm:py-16">
      <${PageHeader} title="Contact">
        Want to work together or have a question about my projects? Send me a message.
      <//>

      <ul className="mt-12 grid gap-4 sm:grid-cols-2">
        ${CONTACT_LINKS.map(
          (c) => html`
            <li key=${c.label}>
              <${ExternalLink}
                href=${c.href}
                className="block h-full rounded-xl bg-ink p-6 text-white shadow-lg shadow-ink/15 transition-colors hover:bg-ink-2"
              >
                <span className="block text-sm font-semibold text-sky">${c.label}</span>
                <span className="mt-1 block break-words text-lg font-medium">${c.text}</span>
              <//>
            </li>
          `
        )}
      </ul>

      <div className="mt-8">
        <${ExternalLink} href=${GMAIL_COMPOSE_URL} className=${buttonClasses("primary")}>Send me an email<//>
      </div>
    <//>
  `;
}
