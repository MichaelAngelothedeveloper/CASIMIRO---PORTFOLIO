function Home() {
  usePageTitle("");

  return html`
    <div>
      <${Container}>
        <section className="grid items-center gap-12 py-14 sm:py-20 lg:grid-cols-2 lg:gap-16 lg:py-28">
          <div className="min-w-0">
            <p className="text-lg font-medium text-brand">${PORTFOLIO.role}</p>
            <h1 className="mt-3 font-display text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl xl:text-7xl">
              ${PORTFOLIO.name}
            </h1>
            <p className="mt-6 max-w-xl text-lg text-ink-soft sm:text-xl">${PORTFOLIO.intro}</p>
            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <${ButtonLink} to="/projects">View my projects<//>
              <${ButtonLink} to="/contact" variant="secondary">Contact me<//>
            </div>
            <div className="mt-10">
              <h2 className="mb-3 font-display text-base font-bold text-ink-soft">Tech I use</h2>
              <${SkillChips} items=${PORTFOLIO.skillGroups.flatMap((g) => g.items)} />
            </div>
          </div>
          <${CodeCard} />
        </section>
      <//>

      <section className="bg-tint py-14 sm:py-20" aria-labelledby="featured-heading">
        <${Container}>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 id="featured-heading" className="font-display text-3xl font-extrabold tracking-tight sm:text-4xl">Featured projects</h2>
            <${Link} to="/projects" className="font-semibold text-brand underline underline-offset-4 hover:text-ink">
              See all projects
            <//>
          </div>
          <div className="mt-8 grid gap-8 md:grid-cols-2">
            ${PORTFOLIO.projects.map((p) => html`<${ProjectCard} key=${p.title} project=${p} />`)}
          </div>
        <//>
      </section>

      <${Container} className="py-14 sm:py-20">
        <section className="rounded-2xl border border-line bg-surface p-8 sm:p-12">
          <h2 className="font-display text-3xl font-extrabold tracking-tight">Let's build something together</h2>
          <p className="mt-3 max-w-xl text-lg text-ink-soft">
            Have a project, an internship or a question? Send me a message and I'll get back to you.
          </p>
          <div className="mt-6"><${ButtonLink} to="/contact">Get in touch<//></div>
        </section>
      <//>
    </div>
  `;
}
