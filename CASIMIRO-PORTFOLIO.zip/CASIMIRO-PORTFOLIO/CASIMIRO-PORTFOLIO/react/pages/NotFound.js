function NotFound() {
  usePageTitle("Page not found");

  return html`
    <${Container} className="py-20 sm:py-32">
      <p className="font-display text-7xl font-extrabold text-brand sm:text-9xl">404</p>
      <h1 className="mt-4 font-display text-3xl font-extrabold sm:text-4xl">Page not found</h1>
      <p className="mt-4 max-w-xl text-lg text-ink-soft">
        The page you're looking for doesn't exist or was moved. Check the address, or go back to the home page.
      </p>
      <div className="mt-8"><${ButtonLink} to="/">Back to home<//></div>
    <//>
  `;
}
