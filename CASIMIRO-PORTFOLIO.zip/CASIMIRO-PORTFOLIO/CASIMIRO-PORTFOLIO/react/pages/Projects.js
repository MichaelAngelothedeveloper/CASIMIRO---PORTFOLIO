function Projects() {
  usePageTitle("Projects");

  return html`
    <${Container} className="py-12 sm:py-16">
      <${PageHeader} title="Projects">
        Things I've built for school and for my community.
      <//>
      <div className="mt-12 grid gap-8 md:grid-cols-2">
        ${PORTFOLIO.projects.map((p) => html`<${ProjectCard} key=${p.title} project=${p} />`)}
      </div>
    <//>
  `;
}
