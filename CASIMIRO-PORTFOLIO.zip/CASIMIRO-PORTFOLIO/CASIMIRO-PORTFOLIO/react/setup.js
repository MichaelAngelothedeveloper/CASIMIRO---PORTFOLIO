const html = htm.bind(React.createElement); 
const { useState, useEffect } = React;
const { Link, NavLink, Outlet, useLocation } = ReactRouterDOM;
